LAB 07 - Tempo + OpenTelemetry

Fluxo:
sre-demo -> OTLP/HTTP -> OpenTelemetry Collector -> OTLP/gRPC -> Tempo -> Grafana

Componentes:
- Tempo 3.0.2 monolithic, armazenamento local/emptyDir
- OpenTelemetry Collector Contrib 0.159.0
- OpenTelemetry Python SDK 1.44.0
- Flask instrumentation 0.65b0

IMPORTANTE:
- Tempo deste lab usa emptyDir e nao e desenho de producao.
- /healthz e /metrics sao excluidos dos traces.
- Os logs JSON passam a conter trace_id e span_id reais.
- Loki/Alloy nao precisam de alteracao.
