LAB 08 - Loki <-> Tempo Correlation

Objetivo:
1) Clicar em um trace_id de um log no Loki e abrir o trace no Tempo.
2) Abrir um span no Tempo e clicar em "Logs for this span" para abrir os logs no Loki.

A) LOKI -> TEMPO

Grafana:
Connections -> Data sources -> Loki
Additional settings -> Derived fields -> Add

Name:
TraceID

Type:
Regex in log line

Regex:
"trace_id":"([0-9a-fA-F]{32})"

Internal link:
Enabled

Data source:
Tempo

Query:
${__value.raw}

Save & test.

Teste no Explore/Loki:
{namespace="sre-lab", app="sre-demo"} | json | duration_ms > 500

Expanda uma linha, clique no campo TraceID e confirme que o trace abre no Tempo.

B) TEMPO -> LOKI

Grafana:
Connections -> Data sources -> Tempo
Trace to logs

Data source:
Loki

Span start time shift:
-2s

Span end time shift:
2s

Tags:
k8s.namespace.name -> namespace

Filter by trace ID:
Enabled

Filter by span ID:
Disabled

Use custom query:
Disabled

Save & test.

Teste no Explore/Tempo:
{ resource.service.name = "sre-demo" }

Abra um trace /slow, abra o span e clique em "Logs for this span".

IMPORTANTE:
trace_id nao deve virar label indexado do Loki.
