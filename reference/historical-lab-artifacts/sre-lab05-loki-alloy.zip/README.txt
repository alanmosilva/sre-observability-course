LAB 05 - Loki + Alloy

Objetivo:
stdout/stderr dos Pods -> Alloy -> Loki -> Grafana

Arquivos:
- loki-values.yaml
- alloy-values.yaml

Este lab usa Loki Monolithic com filesystem e sem persistencia propositalmente.
Nao use esta configuracao de storage como desenho de producao.
