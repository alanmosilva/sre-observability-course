#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${1:-http://127.0.0.1:8080}"

for i in $(seq 1 90); do curl -fsS "${BASE_URL}/" >/dev/null; done
for i in $(seq 1 5); do curl -sS "${BASE_URL}/error" >/dev/null; done
for i in $(seq 1 5); do curl -fsS "${BASE_URL}/slow" >/dev/null; done

echo "Done: 100 requests (90 success, 5 error, 5 slow)"
