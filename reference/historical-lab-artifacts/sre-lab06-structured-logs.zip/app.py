import hashlib, json, os, time, uuid
from datetime import datetime, timezone
from flask import Flask, Response, g, jsonify, request
from prometheus_client import Counter, Gauge, Histogram, CONTENT_TYPE_LATEST, generate_latest

app = Flask(__name__)

REQUESTS = Counter("sre_demo_http_requests_total","Total HTTP requests",["method","route","status"])
LATENCY = Histogram("sre_demo_http_request_duration_seconds","HTTP request duration in seconds",["method","route"],
                    buckets=(0.05,0.1,0.25,0.5,1,2,3,5,7.5,10,15,20,30))
IN_PROGRESS = Gauge("sre_demo_http_requests_in_progress","HTTP requests currently in progress")
EXCLUDED_PATHS={"/metrics","/healthz"}

def normalized_route():
    return request.url_rule.rule if request.url_rule is not None else "unmatched"

def emit(payload):
    print(json.dumps(payload,separators=(",",":")),flush=True)

@app.before_request
def before():
    g.request_id=request.headers.get("X-Request-ID") or str(uuid.uuid4())
    g.started_at=time.perf_counter()
    g.exception_type=None
    if request.path not in EXCLUDED_PATHS:
        IN_PROGRESS.inc()

@app.after_request
def after(response):
    if request.path not in EXCLUDED_PATHS:
        duration=max(time.perf_counter()-g.started_at,0)
        route=normalized_route()
        REQUESTS.labels(request.method,route,str(response.status_code)).inc()
        LATENCY.labels(request.method,route).observe(duration)
        IN_PROGRESS.dec()
        level="ERROR" if response.status_code>=500 else "WARNING" if response.status_code>=400 else "INFO"
        event={
            "timestamp":datetime.now(timezone.utc).isoformat(),
            "level":level,
            "event":"http_request",
            "service":"sre-demo",
            "pod":os.getenv("HOSTNAME","unknown"),
            "request_id":g.request_id,
            "method":request.method,
            "route":route,
            "status":response.status_code,
            "duration_ms":round(duration*1000,2)
        }
        if g.exception_type:
            event["exception_type"]=g.exception_type
        emit(event)
    response.headers["X-Request-ID"]=getattr(g,"request_id","")
    return response

@app.errorhandler(Exception)
def handle_exception(exc):
    g.exception_type=type(exc).__name__
    return jsonify(status="error",error="internal_server_error",request_id=getattr(g,"request_id",None)),500

@app.get("/")
def index():
    return jsonify(status="ok",service="sre-demo")

@app.get("/healthz")
def healthz():
    return jsonify(status="healthy")

@app.get("/error")
def error():
    return jsonify(status="error",message="simulated HTTP 500"),500

@app.get("/exception")
def exception():
    raise RuntimeError("simulated application exception")

@app.get("/slow")
def slow():
    time.sleep(1)
    return jsonify(status="ok",workload="slow")

@app.get("/cpu")
def cpu():
    data=b"sre-cpu-test"
    for _ in range(500000):
        data=hashlib.sha256(data).digest()
    return jsonify(status="ok",workload="cpu")

@app.get("/metrics")
def metrics():
    return Response(generate_latest(),mimetype=CONTENT_TYPE_LATEST)
