LAB 06 - Structured Logs com Loki
- Gera um log JSON por request.
- Alloy continua igual.
- /metrics e /healthz ficam fora dos logs de usuario.
- request_id serve para correlacao neste lab.
- trace_id entra somente no LAB 07 com OpenTelemetry + Tempo.
- Nao transforme request_id em label Loki: alta cardinalidade.
