LAB 10 - Prometheus -> Tempo com Exemplars

O exemplar associa uma observacao de metrica a um trace_id real.

Fluxo:
request -> trace OTel -> trace_id
                  |
                  +-> histogram Prometheus com exemplar trace_id
                              |
                              -> Grafana -> Tempo

Mudancas:
1. app v7: Histogram.observe(... exemplar={"trace_id": trace_id})
2. /metrics passa a expor OpenMetrics.
3. Prometheus deve ter exemplar-storage habilitado.
4. Grafana Prometheus datasource deve mapear trace_id -> Tempo.

IMPORTANTE:
Prometheus client Python so expoe exemplars no formato OpenMetrics.
